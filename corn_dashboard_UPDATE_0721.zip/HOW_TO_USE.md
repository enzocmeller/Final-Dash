# 🌽 US Corn Dashboard — How to Use & Keep It Running

**Read this first.** It explains what everything in this folder is, how to keep the
dashboard up to date, and what a successor needs to know to run it after the
current owner is gone. For deep configuration details see `README.md`; for the
one-page quick start see `SETUP.txt`.

---

## 1. What this is (in one paragraph)

A self-contained corn dashboard for every US state. One Python script
(`run.bat`) pulls fresh USDA + weather + satellite data and rebuilds a single
file, **`index.html`**. That file is the dashboard — open it in any browser,
**no internet or server needed to view it**. Everything the viewer needs is baked
inside. You only need a network connection when you **refresh the data**.

---

## 2. The two things you'll ever do

### A) View it
Double-click **`index.html`**. That's the whole dashboard. It always shows the
data from the last refresh. Works offline, works from a USB stick, works forever.

### B) Refresh the data
Double-click **`run.bat`**. It downloads the latest data and rebuilds
`index.html`. When it finishes, the dashboard opens by itself.
- **First run on a new machine is slow (~30–45 min)** — it builds a one-time
  30-year weather "normals" cache. **Every run after that is a few minutes.**
- Re-run it as often as you want new numbers. That *is* the update — there's no
  other step.

That's the entire job. Everything below is reference and upkeep.

---

## 2b. The three tabs (what you'll actually use)

Across the top of the dashboard there are three tabs:

1. **Dashboard** — the per-state view. Pick a state on the map or dropdown; every
   panel (yield trend, crop condition, NDVI, soil, weather forecast, stress index,
   etc.) updates for that state. This is where you *read* the crop.
   - The **yield trend line** is fit on **2013–present** with drought/outlier years
     removed, so it reflects the recent trajectory (not a diluted 35-year slope).

2. **Desk Forecast** — the editable JBS/GRMI-style crop table. Type your own state
   yields in the **Desk 2026** column and everything (production, the US roll-up)
   recomputes live. States you don't itemize fold into their **regional cluster**
   subtotal; clusters with no itemized states (**Southeast, Others**) are editable
   directly. Buttons: **Save as revision**, **Copy for Excel / .xlsx / CSV**,
   **Export/Import desk yields** (to move your entries between machines).

3. **Report** — a print/PDF-ready page for the risk team. Page 1 is the revision
   map + US implied yield; then one page per state with the key panels.
   - **🖨 Print / Save as PDF** → saves a crisp A3-landscape PDF named
     *"US Corn Yield Suggestion \<date\>"*.
   - **📧 Save PDF & email (Outlook)** → saves the PDF, then opens Outlook with the
     subject and a short professional body pre-filled. **Attach the saved PDF**
     (browsers can't auto-attach a file from an offline page — that's a security
     rule, not a bug), then send.

**Important:** the desk yields, notes, and the editable "Current" numbers live in
**the browser you type them in** (not in the files). Use **Export desk yields** to
carry them to another computer.

---

## 3. Keeping it running after you leave (hand-off)

Whoever takes this over needs only three things:

1. **A Windows PC with Python 3.10+ installed** (from python.org — tick *"Add
   Python to PATH"* during install). Check with `python --version`.
2. **This folder** (with `config.json` inside — it holds the API keys, already
   set up).
3. **Network access** to the five data hosts listed in `SETUP.txt` (IT has
   already approved them). If a refresh ever shows a "carried from…" note on a
   state, one host was unreachable — run `python src\check_connectivity.py` to
   see which.

**To keep the data fresh automatically (optional, recommended for hand-off):**
schedule `run.bat` with Windows Task Scheduler.
- Open **Task Scheduler → Create Basic Task**.
- Trigger: **Daily**, e.g. 6:00 AM.
- Action: **Start a program** → browse to this folder's **`run.bat`**.
- Set *"Start in"* to this folder's path (so it finds `src\` and `config.json`).
- Now the dashboard rebuilds itself every morning with no one touching it.

If you'd rather refresh by hand, just double-click `run.bat` whenever you want
current numbers.

---

## 4. What every file & folder is

| File / folder | Keep? | What it is |
|---|---|---|
| **`index.html`** | ✅ **the deliverable** | The dashboard itself. Open this to view. Rebuilt by `run.bat`. |
| **`run.bat`** | ✅ essential | Double-click entry point — does the full data refresh. |
| **`run.ps1`** | ✅ keep | PowerShell version of `run.bat` (same job). |
| **`config.json`** | ✅ **essential + SECRET** | Your USDA/AMS API keys + settings. **Never share publicly.** |
| **`src\`** | ✅ essential | The engine — all the Python that fetches data and builds the HTML. Don't touch unless changing how it works. |
| **`templates\dashboard.html`** | ✅ essential | The master template. `run.bat` rebuilds `index.html` **from this**. To change the dashboard's look/features you edit this, not `index.html`. |
| **`assets\`** | ✅ essential | The bundled chart library (`echarts.min.js`), inlined into `index.html` so it works offline. |
| **`data\dashboard_data.json`** | ✅ keep | The latest data snapshot (also baked into `index.html`). Regenerated each run. |
| **`data\cache.sqlite`** | ✅ keep (big) | The speed cache (~100 MB) — climate normals + past NDVI. Deleting it works but makes the next run slow (~30–45 min). |
| **`config.example.json`** | ✅ keep | Blank template for `config.json` (for setting up a fresh machine). |
| **`requirements.txt`** | ✅ keep | Intentionally empty — documents that there's nothing to `pip install`. |
| **`README.md`** | ✅ keep | Full technical reference (all config options, firewall hosts, how it works). |
| **`SETUP.txt`** | ✅ keep | One-page quick start for a new machine. |
| **`.gitignore`** | ✅ keep | Housekeeping (keeps the secret key out of git). |
| `run_ams.bat` / `run_cpc.bat` / `run_hybridmaize.bat` / `run_points.bat` | ➖ optional | Fast single-panel refreshers (see §5). Keep if you use those panels. |
| `SHAREPOINT_DEPLOY_STEPS.md` / `SHAREPOINT_IT_REQUEST.md` | ➖ optional | Only needed if you ever host this on SharePoint. Delete if staying with the local file. |
| **`backups\`** | 🗑 deletable | Old rollback snapshots from past development. Safe to delete once you're happy with the current version (see §7). |
| `__pycache__\` folders + `*.pyc` | 🗑 deletable | Python's auto-generated bytecode. Harmless; regenerates itself. |

---

## 5. Optional fast refreshers

`run.bat` refreshes **everything**. If you only need one thing updated the same
day without the full pull, these each finish in about a minute:

- **`run_ams.bat`** — just the daily USDA cash bids (the Cash Price panel).
- **`run_cpc.bat`** — just the NOAA 8–14 day outlook pop-up.
- `run_hybridmaize.bat` / `run_points.bat` — other single-source refreshes.

---

## 6. Two things that DON'T travel with this folder

- **Your desk yields & notes** (the Desk Forecast and Report tabs) are saved in
  **the browser you type them in**, not in these files. If you switch computers,
  use the **"Export desk yields"** button to carry them over. This is why the
  same `index.html` can look different on two machines.
- **The Report tab's yield baseline** ("Current" / "USDA-implied") is a fixed
  reference number, not something a data refresh moves (see §7). The forecast,
  condition, NDVI and soil panels *do* update every refresh.

---

## 7. Seasonal / yearly upkeep (important)

The forecast, weather, condition, NDVI and soil data update on their own every
run. **The yield anchor does not** — it's set by hand on purpose, so it needs
attention twice a year:

1. **Before August each year** — the pre-harvest US yield anchor lives in
   `config.json` as `usda_us_yield_seed` (currently `183.0`). Update it if the
   USDA WASDE trend yield changes. **From ~Aug 12** the tool auto-replaces it
   with USDA's real published national yield, so after mid-August it's live on
   its own.
2. **The per-state implied yields** shown in the Report tab come from a reference
   table (`USDA2026_REF`) near the top of `templates\dashboard.html`, maintained
   by hand from the desk's official file. Update that table when the desk's
   implied numbers change, then run `python src\update.py --rebuild`.
3. **New crop year (e.g. into 2027)** — the dashboard is pinned to the current
   crop year and will show a loud warning if it's run in a later year without
   updating the anchor year in `templates\dashboard.html`. When that happens,
   bump the crop year and refresh the reference numbers.

---

## 8. Common problems

| Symptom | Fix |
|---|---|
| `python` not recognized | Install Python 3.10+ from python.org, tick *Add to PATH*, reopen the terminal. |
| A state shows "carried from…" | A data host was unreachable during the run. Run `python src\check_connectivity.py` to see which; re-run `run.bat` later. |
| `CERTIFICATE_VERIFY_FAILED` | Corporate TLS proxy — set `"ca_bundle"` in `config.json` to your company root-CA `.pem` (see README §Firewall). |
| Changed the look but `index.html` didn't update | Run `python src\update.py --rebuild` (rebuilds from the template with no network). |
| Dashboard looks stale after editing `index.html` directly | Don't edit `index.html` — edit `templates\dashboard.html`, then rebuild. `run.bat` overwrites `index.html`. |

---

## 9. Quick reference

```
View the dashboard ........ open  index.html
Refresh all data .......... run   run.bat
Rebuild look only ......... python src\update.py --rebuild
Refresh cash bids only .... run   run_ams.bat
Check what's reachable .... python src\check_connectivity.py
```
