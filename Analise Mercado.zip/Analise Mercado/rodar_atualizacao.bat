@echo off
REM ==========================================================================
REM  Atualiza os dados da API e recalcula o Excel (1 clique).
REM  Feche o Analise_Mercado_Micoproteina_JBS.xlsx antes de rodar.
REM ==========================================================================
cd /d "%~dp0"
python atualizar_excel.py
echo.
pause
