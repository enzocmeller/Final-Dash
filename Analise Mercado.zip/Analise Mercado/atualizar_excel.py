#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MICOPROTEINA - orquestrador dinamico
====================================
1) roda micoproteina_dados.py  (APIs -> comercio.csv, populacao.csv)
2) abre o workbook no Excel (COM), garante uma QUERY conectada por CSV,
   da Refresh All, recalcula e salva.
Um comando so atualiza os dados da API E toda a cadeia de calculo.

    python atualizar_excel.py              (fetch + refresh + recalc + salvar)
    python atualizar_excel.py --no-fetch   (so refresh/recalc)
Requisitos: Windows + Excel + pywin32.
"""
import os, sys, time, subprocess
from pathlib import Path
try:
    import win32com.client
except ImportError:
    raise SystemExit("pywin32 necessario:  python -m pip install pywin32")

BASE_DIR = Path(__file__).resolve().parent
FETCH    = BASE_DIR / "micoproteina_dados.py"
WORKBOOK = BASE_DIR / "Analise_Mercado_Micoproteina_JBS.xlsx"

# (arquivo CSV, aba de destino, nome da query)
FEEDS = [
    ("comercio.csv",  "Comercio",  "q_comercio"),
    ("populacao.csv", "Populacao", "q_populacao"),
]

xlDelimited=1; xlInsertDeleteCells=1; xlDoubleQuote=1; xlAutomatic=-4105

def run_fetch():
    print("[1/3] Atualizando dados da API...")
    r=subprocess.run([sys.executable, str(FETCH)], check=False)
    if r.returncode!=0: raise RuntimeError(f"fetch falhou (exit {r.returncode})")

def make_or_refresh(ws, csv_path, qname):
    if ws.QueryTables.Count > 0:
        for i in range(1, ws.QueryTables.Count+1):
            ws.QueryTables(i).Refresh(False)
        return
    qt=ws.QueryTables.Add(Connection="TEXT;"+str(csv_path), Destination=ws.Range("A3"))
    try: qt.Name=qname
    except Exception: pass
    qt.TextFileParseType=xlDelimited
    qt.TextFileCommaDelimiter=True
    qt.TextFileConsecutiveDelimiter=False
    qt.TextFileTextQualifier=xlDoubleQuote
    try: qt.TextFilePlatform=65001
    except Exception: pass
    qt.RefreshStyle=xlInsertDeleteCells
    qt.AdjustColumnWidth=True
    qt.BackgroundQuery=False
    try: qt.SaveData=True
    except Exception: pass
    qt.Refresh(False)

def refresh_workbook():
    if not WORKBOOK.exists(): raise FileNotFoundError(WORKBOOK)
    print("[2/3] Abrindo Excel e conectando as queries...")
    excel=win32com.client.DispatchEx("Excel.Application")
    excel.Visible=False; excel.DisplayAlerts=False
    try: excel.AskToUpdateLinks=False
    except Exception: pass
    wb=None
    try:
        wb=excel.Workbooks.Open(str(WORKBOOK), UpdateLinks=0, ReadOnly=False)
        try: wb.AutoSaveOn=False
        except Exception: pass
        for csv_name, sheet, qname in FEEDS:
            path=BASE_DIR/csv_name
            if not path.exists():
                print(f"      (aviso: {csv_name} nao encontrado, pulando)"); continue
            make_or_refresh(wb.Worksheets(sheet), path, qname)
            print(f"      query '{qname}' -> aba {sheet} OK")
        print("[3/3] Recalculando e salvando...")
        try:
            excel.Calculation=xlAutomatic
            excel.CalculateFull()
            excel.CalculateUntilAsyncQueriesDone()
        except Exception: pass
        deadline=time.time()+180
        while time.time()<deadline:
            try:
                if excel.CalculationState==0: break
            except Exception: break
            time.sleep(0.4)
        wb.Save(); print("      Salvo:", WORKBOOK.name)
    finally:
        if wb is not None:
            try: wb.Close(SaveChanges=False)
            except Exception: pass
        excel.Quit()

def main():
    try:
        if "--no-fetch" not in sys.argv: run_fetch()
        refresh_workbook()
        print("Pronto. Excel dinamico atualizado.")
        return 0
    except Exception as e:
        print("ERRO:", e); return 1

if __name__=="__main__":
    raise SystemExit(main())
