#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MICOPROTEINA - feeds de dados (CSV estaveis para as queries do Excel)
=====================================================================
Puxa dados PUBLICOS de API e escreve CSVs de nome FIXO (para as conexoes do
Excel nunca quebrarem):

  comercio.csv    - UN Comtrade: volumes (t) e valores (US$) de comercio dos
                    codigos-proxy de proteina (HS 210610, 350400) por regiao.
  populacao.csv   - World Bank: populacao (SP.POP.TOTL) de Brasil, EUA, UE.

O preco unitario (US$/t) e derivado no proprio Excel = valor_usd / toneladas.
(micoproteina NAO tem codigo HS proprio -> 210610/350400 sao proxies amplos.)

Rodar:
  python micoproteina_dados.py               (atualiza os dois CSVs)
  python micoproteina_dados.py --selftest    (testa conexao/chave)

Chave do Comtrade: variavel COMTRADE_KEY ou arquivo api_keys.env.
World Bank nao usa chave. Sem dependencias pip (so stdlib + curl do Windows).
"""
import os, sys, csv, json, time, ssl, shutil, subprocess
import urllib.request, urllib.parse

try:
    sys.stdout.reconfigure(encoding="utf-8", line_buffering=True)
except Exception:
    pass

BASE_DIR   = os.path.dirname(os.path.abspath(__file__))
CSV_TRADE  = os.path.join(BASE_DIR, "comercio.csv")
CSV_POP    = os.path.join(BASE_DIR, "populacao.csv")
COMTRADE_URL = "https://comtradeapi.un.org/data/v1/get/C/A/HS"
WB_URL       = "https://api.worldbank.org/v2/country/BRA;USA;EUU/indicator/SP.POP.TOTL"

# UE-27 usa o reporter agregado 97 (importacao EXTRA-UE, sem dupla contagem intra-bloco). Reino Unido separado.
REPORTERS = {76:"Brasil", 842:"EUA", 97:"Uniao Europeia", 826:"Reino Unido"}
CMDS  = {"210610":"Concentrados/proteina texturizada"}  # onde cai o concentrado de micoproteina (3504 e quimico/nao-alimentar)
FLOWS = {"M":"Importacao", "X":"Exportacao"}
YEARS = "2019,2020,2021,2022,2023"
WB_REGION = {"BRA":"Brasil", "USA":"EUA", "EUU":"Uniao Europeia"}
INSECURE = os.environ.get("COMTRADE_INSECURE","").strip() not in ("","0","false","False")

def bloco(rc, rn): return rn

def load_key():
    k = os.environ.get("COMTRADE_KEY","").strip()
    if k: return k
    envf = os.path.join(BASE_DIR, "api_keys.env")
    if os.path.exists(envf):
        for line in open(envf, encoding="utf-8"):
            line=line.strip()
            if line.startswith("COMTRADE_KEY") and "=" in line:
                return line.split("=",1)[1].strip()
    raise SystemExit("Chave do Comtrade nao encontrada (COMTRADE_KEY ou api_keys.env).")

# ---- transportes de rede ---------------------------------------------------- #
def _urllib(url, headers):
    ctx = ssl._create_unverified_context() if INSECURE else ssl.create_default_context()
    req = urllib.request.Request(url, headers=headers)
    op  = urllib.request.build_opener(urllib.request.ProxyHandler(),
                                      urllib.request.HTTPSHandler(context=ctx))
    with op.open(req, timeout=90) as r: return r.read().decode("utf-8","replace")

def _curl(url, headers):
    exe = shutil.which("curl") or shutil.which("curl.exe")
    if not exe: raise RuntimeError("curl ausente")
    a=[exe,"-s","-S","--fail","--location","--max-time","90"]
    if os.name=="nt": a.append("--ssl-no-revoke")
    if INSECURE: a.append("-k")
    for k,v in headers.items(): a += ["-H", f"{k}: {v}"]
    a.append(url)
    p=subprocess.run(a, capture_output=True, timeout=120)
    if p.returncode!=0: raise RuntimeError(f"curl {p.returncode}: {p.stderr.decode('utf-8','ignore')[:200]}")
    return p.stdout.decode("utf-8","replace")

_ORDER=(["curl","urllib"] if os.name=="nt" else ["urllib","curl"]); _last=[None]
def http_get(url, headers=None):
    headers=headers or {}; errs=[]
    for name in _ORDER:
        try:
            t=(_curl if name=="curl" else _urllib)(url, headers)
            if _last[0]!=name: print(f"  [rede] '{name}'"); _last[0]=name
            return t
        except Exception as e: errs.append(f"{name}: {e}")
    raise RuntimeError("Falha de rede:\n  "+"\n  ".join(errs))

# ---- Comtrade --------------------------------------------------------------- #
def comtrade(reporter, cmd, flow, key, retries=3):
    q=urllib.parse.urlencode({"reporterCode":reporter,"period":YEARS,"partnerCode":0,
        "partner2Code":0,"motCode":0,"customsCode":"C00","cmdCode":cmd,"flowCode":flow})
    hdr={"Ocp-Apim-Subscription-Key":key}; last=None
    for a in range(1,retries+1):
        try:
            t=http_get(COMTRADE_URL+"?"+q, hdr)
            return (json.loads(t).get("data") or []) if t.strip() else []
        except Exception as e:
            last=e
            if a<retries: print(f"  retry {a}: {str(e)[:120]}"); time.sleep(2*a)
    raise RuntimeError(f"Comtrade {reporter}/{cmd}/{flow}: {last}")

def fetch_trade(key):
    out=[]; total=len(REPORTERS)*len(CMDS)*len(FLOWS); done=0
    for rc,rn in REPORTERS.items():
        for cmd,desc in CMDS.items():
            for fl,flname in FLOWS.items():
                for row in comtrade(rc,cmd,fl,key):
                    if not row.get("netWgt"): continue
                    out.append({"fonte":"UN Comtrade","codigo_hs":cmd,"descricao":desc,
                        "regiao":rn,"bloco":bloco(rc,rn),"fluxo":flname,"ano":int(row["period"]),
                        "toneladas":round((row.get("netWgt") or 0)/1000.0,3),
                        "valor_usd":round(row.get("primaryValue") or 0.0,2)})
                done+=1; print(f"  [{done}/{total}] {rn} {cmd} {flname}: ok"); time.sleep(1.2)
    out.sort(key=lambda d:(d["codigo_hs"],d["bloco"],d["regiao"],d["fluxo"],d["ano"]))
    _write(CSV_TRADE, ["fonte","codigo_hs","descricao","regiao","bloco","fluxo","ano","toneladas","valor_usd"], out)

# ---- World Bank ------------------------------------------------------------- #
def fetch_pop():
    url=WB_URL+"?format=json&date=2018:2023&per_page=300"
    d=json.loads(http_get(url))
    out=[]
    for e in (d[1] or []):
        cid=e.get("countryiso3code") or e.get("country",{}).get("id")
        reg=WB_REGION.get(cid)
        if not reg or e.get("value") is None: continue
        out.append({"fonte":"World Bank","regiao":reg,"ano":int(e["date"]),"populacao":int(e["value"])})
    out.sort(key=lambda d:(d["regiao"],d["ano"]))
    _write(CSV_POP, ["fonte","regiao","ano","populacao"], out)

def _write(path, fields, rows):
    tmp=path+".tmp"
    with open(tmp,"w",encoding="utf-8-sig",newline="") as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)
    os.replace(tmp,path)
    print(f"Escrito {os.path.basename(path)} ({len(rows)} linhas).")

def main():
    key=load_key()
    if "--selftest" in sys.argv or "--check" in sys.argv:
        print("Comtrade:", len(comtrade(76,"210610","M",key)), "reg. (Brasil)")
        print("World Bank OK"); fetch_pop(); return
    print("[Comercio] UN Comtrade ..."); fetch_trade(key)
    print("[Populacao] World Bank ..."); fetch_pop()
    print("\nOK. Atualize o Excel:  rodar_atualizacao.bat  (ou Dados > Atualizar Tudo).")

if __name__=="__main__":
    main()
