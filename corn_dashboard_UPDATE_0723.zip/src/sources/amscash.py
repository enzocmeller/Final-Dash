"""USDA AMS Market News — DAILY corn cash bids + basis (the real spot price).

Unlike NASS "price received" (a monthly survey average, ~2 months lagged), AMS publishes
each state's actual elevator/terminal CASH BIDS every business day, with the basis vs the
CBOT futures month. Pulled from the MARS API (marsapi.ams.usda.gov) at BUILD time and inlined
like everything else — the firewall-locked runtime never calls it. Needs a free MARS API key
(config ``ams_api_key``); returns None everywhere the key is missing / a state has no report.

Each state's report lists several regional districts; we AGGREGATE the latest day to a single
representative state cash price + basis, and keep a daily history for the chart.
"""
import base64
import datetime
import json
import urllib.parse
import urllib.request

import cache

BASE = "https://marsapi.ams.usda.gov/services/v1.2/reports"

# state -> MARS report slug for its DAILY corn grain-bid report (state-titled reports only;
# regional terminal reports like Portland / IA-MN barge are intentionally excluded).
STATE_REPORT = {
    "AR": 2960, "CA": 3146, "CO": 2912, "IA": 2850, "IL": 3192, "IN": 3463, "KS": 2886,
    "KY": 2892, "MD": 2714, "MN": 3049, "MO": 2932, "MS": 2928, "MT": 2771, "NC": 3156,
    "ND": 3878, "NE": 3225, "OH": 2851, "OK": 3100, "PA": 3091, "SC": 2787, "SD": 3186,
    "TN": 3088, "TX": 2711, "VA": 3167, "WY": 3239,
}
REPORT_URL = "https://mymarketnews.ams.usda.gov/viewReport/"


def _num(x):
    if x is None:
        return None
    try:
        return float(str(x).replace(",", "").replace("$", "").strip())
    except (TypeError, ValueError):
        return None


def _get(key, url, timeout, ca_bundle):
    auth = "Basic " + base64.b64encode((key + ":").encode()).decode()
    req = urllib.request.Request(url, headers={"Authorization": auth, "User-Agent": "corn-dashboard"})
    ctx = None
    if ca_bundle:
        import ssl
        ctx = ssl.create_default_context(cafile=ca_bundle)
    with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
        return json.loads(r.read().decode("utf-8", "replace"))


def state_cash(key, usps, today=None, days=180, timeout=60, ca_bundle=""):
    """Daily corn cash bid + basis for one state, aggregated across its districts. Or None."""
    slug = STATE_REPORT.get(usps)
    if not key or not slug:
        return None
    today = today or datetime.date.today()
    ckey = f"amscash:v2:{usps}:{today.isoformat()}"   # v2 = daily basis added to history
    hit = cache.get_json(ckey)
    if hit is not None:
        return hit or None      # cached miss stored as {} -> None

    start = today - datetime.timedelta(days=days)
    q = "commodity=Corn;report_date=%s:%s" % (start.strftime("%m/%d/%Y"), today.strftime("%m/%d/%Y"))
    url = "%s/%d/Report%%20Detail?q=%s" % (BASE, slug, urllib.parse.quote(q))
    try:
        data = _get(key, url, timeout, ca_bundle)
    except Exception:
        return None
    rows = data.get("results") if isinstance(data, dict) else data
    if not rows:
        cache.set_json(ckey, {})
        return None

    # Restrict to the REPRESENTATIVE product: conventional #2-yellow corn only — the raw
    # commodity=Corn query also returns ORGANIC bids (PA organic corn quotes ~$13/bu) and WHITE
    # food-corn premiums (IN/KY), which otherwise pollute the state cash price. Drop them.
    def _keep(r):
        conv = str(r.get("conventional") or "").strip().lower()
        cls = str(r.get("class") or "").strip().lower()
        if conv and conv != "conventional":
            return False
        if cls and "yellow" not in cls:      # keep Yellow or unlabeled; drop White/other
            return False
        return True
    # nearby/spot bid (current delivery) vs forward new-crop — never blend the two, and never
    # average basis across different futures months (Sep vs Dec embeds the calendar spread).
    def _spot(r):
        cur = str(r.get("current") or "").strip().lower()
        if cur:
            return cur == "yes"
        return not str(r.get("delivery_start") or "").strip()
    def _fm(r):
        return r.get("basis Max Futures Month") or r.get("basis Min Futures Month")

    kept = [r for r in rows if _keep(r)]
    rows = kept or rows      # never empty the set if the class/conventional labels are unexpected

    def rprice(r):     # a district's cash $/bu: avg, else mid of min/max
        a = _num(r.get("avg_price"))
        if a is not None:
            return a
        lo, hi = _num(r.get("price Min")), _num(r.get("price Max"))
        return (lo + hi) / 2 if lo is not None and hi is not None else None

    def rbasis(r):     # a district's basis (cents vs futures): mid of min/max
        lo, hi = _num(r.get("basis Min")), _num(r.get("basis Max"))
        if lo is not None and hi is not None:
            return (lo + hi) / 2
        return lo if lo is not None else hi

    # daily history: mean district SPOT cash price per report_date (fall back to all-horizon
    # only when a date has no nearby-spot rows, so the series stays a single, comparable horizon)
    by_date = {}
    for r in rows:
        d = r.get("report_date")
        p = rprice(r)
        if not d or p is None:
            continue
        slot = by_date.setdefault(d, {"spot": [], "all": [], "basis": []})
        slot["all"].append(p)
        if _spot(r):
            slot["spot"].append(p)
            b = rbasis(r)
            if b is not None:
                slot["basis"].append(b)
    if not by_date:
        cache.set_json(ckey, {})
        return None

    def pd(s):
        return datetime.datetime.strptime(s, "%m/%d/%Y")

    hist = sorted(by_date, key=pd)
    history = [{"date": pd(d).strftime("%Y-%m-%d"),
                "price": round(sum(by_date[d]["spot"] or by_date[d]["all"])
                               / len(by_date[d]["spot"] or by_date[d]["all"]), 3),
                "basis": (round(sum(by_date[d]["basis"]) / len(by_date[d]["basis"]), 1)
                          if by_date[d]["basis"] else None)}
               for d in hist]
    latest = hist[-1]
    lall = [r for r in rows if r.get("report_date") == latest]     # conventional-yellow, latest day
    sel = [r for r in lall if _spot(r)] or lall                    # nearby-spot bids (else all)
    # a single, coherent futures month so basis_avg + the "vs <month>" label agree
    fms = [_fm(r) for r in sel if _fm(r)]
    fmonth = max(set(fms), key=fms.count) if fms else None
    fmsel = [r for r in sel if _fm(r) == fmonth] if fmonth else sel
    prices = [rprice(r) for r in sel if rprice(r) is not None]
    bases = [rbasis(r) for r in fmsel if rbasis(r) is not None]     # basis only vs the ONE futures month
    pmins = [_num(r.get("price Min")) for r in sel if _num(r.get("price Min")) is not None]
    pmaxs = [_num(r.get("price Max")) for r in sel if _num(r.get("price Max")) is not None]
    bunit = (fmsel[0].get("basis_unit") if fmsel else (sel[0].get("basis_unit") if sel else None))
    _locs = set(filter(None, (r.get("trade_loc") or r.get("location_City") for r in sel)))

    out = {
        "report_date": pd(latest).strftime("%Y-%m-%d"),
        "avg_price": round(sum(prices) / len(prices), 3) if prices else None,
        "price_min": round(min(pmins), 2) if pmins else None,
        "price_max": round(max(pmaxs), 2) if pmaxs else None,
        "basis_avg": round(sum(bases) / len(bases), 1) if bases else None,  # cents vs the ONE futures month
        "basis_unit": bunit,
        "futures_month": fmonth,
        "n_districts": len(_locs) or len(sel),
        "history": history[-180:],
        "slug_id": slug,
        "report_title": (sel[0].get("report_title") if sel else None),
        "source_url": REPORT_URL + str(slug),
        "source": "USDA AMS Market News (daily cash grain bids)",
    }
    cache.set_json(ckey, out)
    return out
